-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2024 at 04:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cbpos_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(30) NOT NULL,
  `name` varchar(250) NOT NULL,
  `description` text DEFAULT NULL,
  `image_path` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `description`, `image_path`, `status`, `delete_flag`, `date_created`) VALUES
(7, 'Skintific', 'Skintific adalah brand kecantikan lokal yang diformulasikan di Kanada dan sudah berdiri sejak tahun 1957. Brand ini dikenal memiliki produk skincare yang berkualitas dan aman untuk digunakan. Selama bertahun-tahun, Skintific telah menghasilkan berbagai macam produk skincare yang dapat membantu memperbaiki berbagai masalah kulit, salah satunya skin barrier yang terganggu.', NULL, 1, 0, '2024-06-01 15:28:58'),
(8, 'Originote', 'The Originote adalah merek skincare yang berdiri pada tahun 2022 dan sudah memiliki beberapa rangkaian skincare yang di sesuaikan dengan setiap masalah kulit dan dapat di gunakan mulai usia 13 tahun (remaja). Setiap produk memiliki fungsi untuk masing masing masalah kulit dengan kandungan yang advanced namun dengan harga yang terjangkau. Rangkaian produk The Originote dapat digunakan oleh siapa saja tidak terbatas umur dan kalangan, sesuai dengan visi dan tagline - nya yaitu “Affordable Skincare for All\"', NULL, 1, 0, '2024-06-01 16:11:27'),
(9, 'Wardah', 'Wardah adalah merek produk kecantikan (kosmetik) yang diproduksi oleh salah satu perusahaan manufaktur komestik terbesar di Indonesia besutan Nurhayati Subakat, PT Paragon Technology and Innovation. Wardah diperkenalkan tahun 1995.Empat tahun kemudian, merek ini mendapatkan sertifikat halal dari LPPOM MUI, yang menjadikannya sebagai pelopor merek halal produk kecantikan di Indonesia.[', NULL, 1, 0, '2024-06-01 16:16:29'),
(10, 'Emina', 'Emina merupakan salah satu brand kosmetika lokal yang baru diluncurkan dipasaran Indonesia pada tahun 2015 oleh PT Paragon Technology and Innovation. Emina adalah sebuah brand kosmetika yang berfokus pada produk perawatan dan kosmetika yang aman digunakan serta mudah diaplikasikan untuk kulit remaha dan wanita muda.', NULL, 1, 0, '2024-06-01 16:17:36'),
(11, 'Somethinc', 'Somethinc merupakan brand kecantikan dan skincare lokal asal Indonesia. Somethinc didirikan sejak Mei 2019 oleh Irene Ursula, yang sebelumnya Irene telah mendirikan e-commerce kecantikan bernama BEAUTYHAUL pada tujuh tahun lalu (Parapuan.co, 2021).', NULL, 1, 0, '2024-06-01 16:18:56'),
(12, 'Makeover', 'brand Make Over merupakan produk kosmetik asli dari Indonesia. Make Over berada di bawah perusahaan Paragon Technology and Inovation yang juga menjadi induk dari produk Wardah Cosmetic, Emina dan Kahf.', NULL, 1, 0, '2024-06-01 16:20:56'),
(13, 'Rose All Day', 'Rose All Day atau RADC (Rose All Day Co) merupakan brand makeup lokal baru yang didirikan oleh tiga orang wanita Indonesia. Hingga saat ini RADC baru mengeluarkan produk lip & cheek-nya awal tahun kemarin. RADC bisa dibilang sebagai brand yang unik. Visi kecantikan mereka berbeda dari kebanyakan brand indie lokal yang ada hingga saat ini.', NULL, 1, 0, '2024-06-01 16:28:01'),
(14, 'ESQA', 'ESQA adalah merek Kosmetik Vegan pertama di Indonesia yang menyediakan produk berkualitas tinggi yang dikemas secara glamor dengan harga terjangkau untuk memaksimalkan kecantikan alami Anda. ESQA dimulai dengan semangat untuk membangun merek kecantikan inovatif yang berfokus pada bahan-bahan yang aman dan mengembangkan produk yang terdepan di kancah tata rias internasional.', NULL, 1, 0, '2024-06-01 16:32:45'),
(15, 'LUXCRIME', 'LUXCRIME adalah perusahaan kosmetik dan perawatan kulit yang terinspirasi oleh kecantikan wanita Indonesia, kami hadir untuk menyediakan produk berkualitas dari kulit hingga riasan wajah dengan tujuan untuk meningkatkan kecantikan dan keanggunan perempuan Indonesia.', NULL, 1, 0, '2024-06-01 16:34:41'),
(16, 'Nivea', 'Nivea merupakan brand perawatan kulit dan tubuh asal Jerman yang pertama kali diperkenalkan tahun 1911. Produk Nivea kini bervariasi mulai dari produk perawatan wajah (skincare Nivea), perawatan tubuh, tabir surya, krim, hingga perawatan kulit pria.', NULL, 1, 0, '2024-06-01 17:00:35');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(30) NOT NULL,
  `client_id` int(30) NOT NULL,
  `inventory_id` int(30) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(30) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `client_id`, `inventory_id`, `price`, `quantity`, `date_created`) VALUES
(13, 3, 7, 50000, 1, '2024-06-01 16:52:39'),
(21, 5, 10, 22500, 1, '2024-06-05 10:01:23');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(30) NOT NULL,
  `category` varchar(250) NOT NULL,
  `description` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `description`, `status`, `delete_flag`, `date_created`) VALUES
(1, 'Skin Care', 'Skincare merupakan rangkaian aktivitas untuk mendukung kesehatan kulit khususnya wajah dengan menggunakan produk-produk tertentu. Wajah merupakan salah satu hal yang penting untuk dijaga dalam berpenampilan. Karena, wajah merupakan salah satu bagian yang menjadi pusat perhatian.', 1, 0, '2022-02-17 11:27:11'),
(2, 'Cushion', 'Berbeda dengan bedak cushion, jenis bedak satu ini bisa digunakan sebagai base makeup. Hal ini karena di dalam formula cushion terdapat foundation. Maka dari itu, tak heran jika hasil dari penggunaan cushion dapat menutupi noda lebih sempurna dibandingkan hanya menggunakan bedak biasa.', 1, 0, '2022-02-17 11:27:24'),
(3, 'Body Care', 'perawatan kulit tubuh yang dilakukan untuk menjaga kesehatan serta kecantikan kulit agar terawat dengan baik. Rutinitas bodycare sangat diperlukan agar kulit tetap sehat dan terawat. Namun, kamu juga perlu memperhatikan kandungan dalam produk bodycare yang akan kamu gunakan. Pilih produk bodycare dengan kandungan yang sesuai dengan kebutuhan atau permasalahan kulitmu.', 1, 0, '2022-02-17 11:27:45'),
(4, 'Eyeshadow', 'Eye shadow  adalah kosmetik yang diaplikasikan terutama pada kelopak mata untuk menarik perhatian mata pemakainya, membuatnya menonjol atau terlihat lebih menarik. Eye shadow juga bisa diaplikasikan di bawah mata, di pipi, atau di tulang alis.', 1, 0, '2022-02-17 11:27:55'),
(5, 'Hair Care', 'Hair care tidak hanya shampo saja, Toppers, melainkan ada berbagai nutrisi dan vitamin rambut yang wajib kamu gunakan. Selain membuat rambut sehat, perawatan rambut juga bisa membuat rambut berkilau, mudah diatur, kuat, hingga mampu mengatasi berbagai masalah rambut', 1, 0, '2022-02-17 11:28:38'),
(6, 'Jenis kulit', 'Adapun indikator yang dapat diperhatikan adalah sebagai berikut:\r\n1. Kulit wajah normal: Hanya terdapat sedikit noda minyak pada tisu/kertas minyak\r\n2. Kulit wajah berminyak: Terdapat banyak noda minyak pada tisu/kertas minyak.\r\n3. Kulit wajah kering: Tidak terdapat noda minyak atau tisu/kertas minyak tidak menempel pada wajah.', 0, 1, '2022-02-17 11:29:00'),
(8, 'Lipsticks', 'Lipstik adalah jenis kosmetik yang sangat populer pada wanita dan digunakan hampir oleh semua wanita setiap hari. Lipstik dirancang untuk memperbaiki penampilan alami bibir, menimbulkan perubahan warna, meningkatkan kilau dan menghaluskan garis keriput serta lipatan pada bibir.', 1, 0, '2022-02-17 11:29:38'),
(9, 'Lip Tint', 'Lip tint adalah salah satu produk pewarna bibir yang populer beberapa tahun ini. Produk ini dipopulerkan Korean beauty ke seluruh dunia, termasuk Indonesia. Pewarna bibir ini populer dengan teksturnya yang ringan dan tampilannya yang natural. Produk ini juga terkenal sangat ideal untuk dipakai sehari-hari.', 1, 0, '2022-02-17 11:29:59');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(30) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` text NOT NULL,
  `default_delivery_address` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `firstname`, `lastname`, `gender`, `contact`, `email`, `password`, `default_delivery_address`, `status`, `delete_flag`, `date_created`) VALUES
(3, 'Miftahul', 'Jannah', 'Female', '081622983', 'admin@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '', 1, 0, '2024-06-01 09:56:21'),
(4, 'Miftahul', 'Jannah', 'Female', '081368182084', 'msyarifhidayatullah2001@gmail.com', 'e32811820a82fdd003d6d9f99455b776', '', 1, 0, '2024-06-02 10:15:21'),
(5, 'Miftahul', 'Jannah', 'Female', '081368182084', 'miftahuljannah16305@gmail.com', '150bfb5c3fcc30c477b8253721262363', 'Desa Meranjat 2 dusun 1, Kec. Indralaya Selatan, Kab. Ogan Ilir', 1, 0, '2024-06-02 22:29:53'),
(6, 'tiara', 'utami', 'Female', '0876543582663', 'tiara@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'km', 1, 0, '2024-06-07 09:46:36'),
(7, 'Sari', 'Indah', 'Female', '08927654679', 'sari123@gmail.com', 'e9ee75b57bb1303190c8869621cad05b', 'palembang', 1, 0, '2024-06-07 14:10:35');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(30) NOT NULL,
  `variant` text NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` double NOT NULL,
  `price` float NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `variant`, `product_id`, `quantity`, `price`, `date_created`, `date_updated`) VALUES
(7, '4', 7, 100, 50000, '2024-06-01 16:51:26', NULL),
(8, '12', 8, 50, 70000, '2024-06-01 16:52:09', NULL),
(9, '1', 9, 30, 40000, '2024-06-01 16:57:58', NULL),
(10, '5', 10, 70, 22500, '2024-06-01 17:05:48', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(30) NOT NULL,
  `ref_code` varchar(100) NOT NULL,
  `client_id` int(30) NOT NULL,
  `delivery_address` text NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `order_type` tinyint(1) NOT NULL COMMENT '1= pickup,2= deliver',
  `amount` double NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT 0 COMMENT '0 = pending,\r\n1= Packed,\r\n2 = Out for Delivery,\r\n3=Delivered,\r\n4=cancelled',
  `paid` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `ref_code`, `client_id`, `delivery_address`, `payment_method`, `order_type`, `amount`, `status`, `paid`, `date_created`, `date_updated`) VALUES
(6, '20240600001', 4, 'meranjat', 'cod', 0, 22500, 3, 1, '2024-06-02 10:17:01', '2024-06-02 22:31:48'),
(7, '20240600002', 5, 'Desa Meranjat 2 dusun 1, Kec. Indralaya Selatan, Kab. Ogan Ilir', 'cod', 0, 22500, 3, 1, '2024-06-02 22:30:19', '2024-06-04 08:21:08'),
(8, '20240600003', 5, 'Desa Meranjat 2 dusun 1, Kec. Indralaya Selatan, Kab. Ogan Ilir', 'cod', 0, 50000, 3, 1, '2024-06-04 08:15:43', '2024-06-04 08:21:34'),
(9, '20240600004', 7, 'palembang', 'cod', 0, 50000, 3, 1, '2024-06-07 14:11:20', '2024-06-07 14:14:25'),
(10, '20240600005', 7, 'palembang', 'cod', 0, 200000, 0, 0, '2024-06-07 14:12:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

CREATE TABLE `order_list` (
  `id` int(30) NOT NULL,
  `order_id` int(30) NOT NULL,
  `inventory_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_list`
--

INSERT INTO `order_list` (`id`, `order_id`, `inventory_id`, `quantity`, `price`, `total`) VALUES
(8, 6, 10, 1, 22500, 22500),
(9, 7, 10, 1, 22500, 22500),
(10, 8, 7, 1, 50000, 50000),
(11, 9, 7, 1, 50000, 50000),
(12, 10, 9, 5, 40000, 200000);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(30) NOT NULL,
  `brand_id` int(30) NOT NULL,
  `category_id` int(30) NOT NULL,
  `name` varchar(250) NOT NULL,
  `specs` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `brand_id`, `category_id`, `name`, `specs`, `status`, `delete_flag`, `date_created`) VALUES
(7, 10, 2, 'Daily Matte Cushion', '&lt;article&gt;\r\n                            &lt;p&gt;Emina Daily Matte Cushion adalah satu-satunya cushion dari Emina memiliki keunggulan sebagai berikut:&lt;/p&gt;\r\n\r\n&lt;p&gt;- Healthy-matte skin-like finish: hasil akhir matte yang tampak sehat, ringan dan menyatu sempurna dengan kulit (tampak natural)&lt;/p&gt;\r\n\r\n&lt;p&gt;- Quick oil control complexion: cushion foundation yang praktis, \r\nmudah diaplikasikan dengan oil absorber yang dapat menahan sebum/minyak \r\ninstan untuk hasil flawless sejak lapisan pertama&lt;/p&gt;\r\n\r\n&lt;p&gt;- 8 hours medium buildable long lasting coverage: selama 8 jam dapat \r\nmemberikan coverage yang medium dan dapat di build sesuai keinginan&lt;/p&gt;\r\n                        &lt;/article&gt;\r\n\r\n                                                &lt;h5&gt;Benefit:&lt;/h5&gt;\r\n                        &lt;article&gt;\r\n                            &lt;p&gt;Keunggulan:&lt;/p&gt;\r\n\r\n&lt;p&gt;- Healthy-matte finish&lt;/p&gt;\r\n\r\n&lt;p&gt;- Ringan&lt;/p&gt;\r\n\r\n&lt;p&gt;- Oil control&lt;/p&gt;\r\n\r\n&lt;p&gt;- SPF 25 PA++&lt;/p&gt;\r\n\r\n&lt;p&gt;- Breathable&lt;/p&gt;\r\n\r\n&lt;p&gt;- Tidak membuat kering&lt;/p&gt;\r\n\r\n&lt;p&gt;- Medium buildable coverage&lt;/p&gt;\r\n                        &lt;/article&gt;\r\n                        \r\n                        \r\n                                                &lt;h5&gt;How To Use:&lt;/h5&gt;\r\n                        &lt;article&gt;\r\n                            &lt;p&gt;1. Ambil cushion menggunakan puff yang disediakan dengan cara menekan sponge&lt;/p&gt;\r\n\r\n&lt;p&gt;2. Aplikasikan cushion ke wajah dengan cara tap-tap secara halus untuk hasil coverage yang optimal dan merata&lt;/p&gt;\r\n\r\n&lt;p&gt;3. Tutup rapat cushion setelah pemakaian&lt;/p&gt;\r\n                        &lt;/article&gt;&lt;p&gt;&lt;/p&gt;\r\n\r\nuploads/liptin esqa.png?', 1, 0, '2024-06-01 16:47:54'),
(8, 14, 9, 'ESQA Slick Drip Serum Lip Tint ', '&lt;p&gt;ESQA Slick Drip Serum Lip Tint adalah lip tint yang ringan dan alami \r\ndengan hasil mengkilap yang tersedia dalam 8 warna segar. Lip tint kami \r\ntahan lama dan memberikan warna yang merata yang bertahan sepanjang \r\nhari. Produk ini memberikan kilau sehat pada bibir dengan hasil akhir \r\nyang licin dan mulus. Diformulasikan dengan pigmen yang kuat, lip tint \r\nini akan memberikan warna yang merata di seluruh bibir Anda. Lip tint \r\nini juga diperkaya dengan serum perawatan bibir untuk melembabkan dan \r\nmenyehatkan bibir Anda, sehingga bibir Anda tetap segar sepanjang hari! \r\nTak peduli warna kulit Anda, ESQA Slick Drip Lip Tint dapat memberikan \r\nnuansa bermain pada bibir Anda.How to use:Aplikasikan pada bibir secara \r\nmerataSuitable for:Semua jenis kulitIngredients:Aqua, Octyldodecanol, \r\nPolyisobutene, Diisostearyl Malate, Glycerin, \r\nBisBehenyl/Isostearyl/Phytosteryl Dimer Dilinoleyl Dimer Dilinoleate, \r\nHydrogenated Styrene/Methylstyrene/Indene Copolymer, \r\nPolyphenylsilsesquioxane, BisDiglyceryl Polyacyladipate-2, Steareth-21, \r\nButylene Glycol, Ethylcellulose, Steareth-2, Phenoxyethanol, \r\nHydroxyethyl Acrylate/Sodium Acryloyldimethyl Taurate Copolymer, Parfum,\r\n Tocopherol, Simmondsia Chinensis (Jojoba) Seed Oil, Helianthus Annuus \r\n(Sunflower) Seed Oil, Silica, Sorbitan Isostearate, Polysorbate 60, \r\nSodium Hyaluronate, Ethylhexylglycerin.&lt;/p&gt;', 1, 0, '2024-06-01 16:49:57'),
(9, 8, 1, 'Moisturizer', '&lt;p&gt;The Originote Hyalucera Moisturizer adalah pelembap yang diformulasikan \r\nuntuk menjaga skin barrier dengan menggunakan gabungan dari bahan aktif \r\nlaboratorium kimia yang teruji secara klinis aman dan bahan natural dari\r\n alam. Diformulasikan dengan Hyaluronic Acid dan Ceramide yang dapat \r\nmemperbaiki dan menjaga skin barrier, mengunci hidrasi pada kulit, \r\nmenjaga elastisitas kulit serta membantu menyembuhkan breakout. \r\nMengandung Chlorelina gabungan antara chlorella dan spirulina yang \r\nberfungsi untuk menjaga elastisitas, sebagai antioksidan bagi kulit, \r\nsebagai oil control dan teksturnya yang gel membuat moisturizer ini \r\ncocok untuk segala jenis kulit. How to use:Setelah membersihkan muka, \r\nmenggunakan toner dan serum, ambil moisturizer secukupnya dan pijat \r\nperlahan ke seluruh muka secara merata, tepuk perlahan dan biarkan \r\nhingga meresap sempurna pada kulit. Suitable for:Semua jenis \r\nkulitIngredients:Hyaluronic Acid + Ceramide with Chlorelina  &lt;/p&gt;', 1, 0, '2024-06-01 16:56:40'),
(10, 16, 3, '  NIVEA Body Lotion Daily Protection Extra White', '&lt;p&gt;&lt;span class=&quot;sh-ds__trunc&quot;&gt;&lt;span class=&quot;sh-ds__trunc-txt translate-content&quot;&gt;NIVEA\r\n Body Lotion Daily Protection Extra White Intensive Moisture Radiant \r\nSmooth Instant Glow Repair Protect 50ml 100ml 200ml 400ml. NIVEA Body \r\nLotion 100ml 200ml 400ml Extra White Intensive Moisture Sensational \r\nDaily Protection Sun Protect Moisture SPF50. hand body lotion nivea \r\nuntuk kulit kering. Nivea extra white instant glow 200 ml. nivea \r\nhandbody untuk kulit kering&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;', 1, 0, '2024-06-01 17:04:55'),
(11, 14, 2, 'cushion esqa', '&lt;p&gt;membuat kulit mulus&lt;/p&gt;', 0, 1, '2024-06-02 22:13:24'),
(12, 11, 4, 'The Nobles eyeshadow', '&lt;h2 class=&quot;pdp-mod-section-title outer-title&quot;&gt;Detail produk dari SOMETHINC - THE NOBLES Eyeshadow Palette&lt;/h2&gt;&lt;div class=&quot;com-struct&quot; id=&quot;hc&quot;&gt;&lt;/div&gt;&lt;div class=&quot;com-struct&quot; id=&quot;hd&quot;&gt;&lt;/div&gt;&lt;div class=&quot;com-struct&quot; id=&quot;bd_-999&quot;&gt;&lt;div class=&quot;com-struct&quot; id=&quot;bd_-999_container_0&quot;&gt;&lt;/div&gt;&lt;/div&gt;\r\n        1. The Nobles Eyeshadow Palette - Volume 1&lt;br&gt;Be a Noble with 12 shades of natural CLY look everyday! &lt;br&gt;Pancarkan pesona anggun nan memukau lewat pallet THE NOBLE, yang mengombinasikan &lt;br&gt;ery\r\n Swatches &amp;amp; Nano-Glitter Shimmers dengan pigmentasi yang intens. \r\nTahan sepanjang hari dengan formulasi yang tahan air serta keringat, \r\nery, mudah diblend, &amp;amp; tanpa fall-out. &lt;br&gt;&lt;br&gt;Ukuran: 8.4gr&lt;br&gt;No BPOM: NA11211200171&lt;br&gt;PAO: 36 months&lt;br&gt;&lt;br&gt;12 warna dalam 1 palette&lt;br&gt;- Travel-friendly&lt;br&gt;- Heavy Duty Pigmentation Pigmentation&lt;br&gt;- Non Fall Out&lt;br&gt;- Easy to Blend&lt;br&gt;- Non-Patchy Non Powdery&lt;br&gt;- Long Lasting&lt;br&gt;- Vegan Friendly&lt;br&gt;&lt;br&gt;Ingredients: &lt;br&gt;Talc,\r\n Mica, Silica, Synthetic Fluorphlogopite, Caprylic/Capric Triglyceride, \r\nDiisostearyl Malate, Pentaerythrityl Tetraisostearate, Magnesium \r\nStearate, Phenyl Trimethicone, Triethoxycaprylylsilane, Dimethicone, \r\nDimethicone Crosspolymer, Paraffin, PTFE, Calcium Titanium Borosilicate,\r\n PEG-8 Dimethicone, Phenoxyethanol, Polymethylsilsesquioxane, \r\nVP/Hexadecene Copolymer, Calcium Aluminum Borosilicate, Octyldodecanol, \r\nIsopropyl Titanium Triisostearate, Tin Oxide, Aluminum Hydroxide, \r\nAlumina, Bismuth Oxychloride, Boron Nitride&lt;br&gt;May conn : &lt;br&gt;CI 77491, CI 77891, CI 77499, CI 77007, CI 15850, CI 77492, Synthetic Fluorphlogopite, CI 77266, CI 45410, CI 19140, CI 73915&lt;br&gt;&lt;br&gt;2. The Nobles Eyeshadow Palette - Volume 2&lt;br&gt;Be a Noble with 12 shades of DARK EXPERIMENTAL look everyday! &lt;br&gt;Pancarkan pesona anggun nan memukau lewat pallet THE NOBLE, yang mengombinasikan &lt;br&gt;ery\r\n Swatches &amp;amp; Nano-Glitter Shimmers dengan pigmentasi yang \r\nintens.Tahan sepanjang hari dengan formulasi yang tahan air serta \r\nkeringat, ery, mudah diblend, &amp;amp; tanpa fall-out. &lt;br&gt;&lt;br&gt;Be Dark, Bold, Experimental, or Glamorous?&lt;br&gt;Semuanya ringkas dalam satu palet yang Travel-friendly!&lt;br&gt;&lt;br&gt;Ukuran: 8.4gr&lt;br&gt;No BPOM: NA11211200172&lt;br&gt;PAO: 36 months&lt;br&gt;&lt;br&gt;12 warna dalam 1 palette&lt;br&gt;- Travel-friendly&lt;br&gt;- Heavy Duty Pigmentation Pigmentation&lt;br&gt;- Non Fall Out&lt;br&gt;- Easy to Blend&lt;br&gt;- Non-Patchy Non Powdery&lt;br&gt;- Long Lasting&lt;br&gt;- Vegan Friendly&lt;br&gt;&lt;br&gt;Ingredients: &lt;br&gt;Talc,\r\n Mica, Silica, Calcium Sodium Borosilicate, Synthetic Fluorphlogopite, \r\nDimethicone, Caprylic/Capric Triglyceride, Triethoxycaprylylsilane, \r\nDiisostearyl Malate, Pentaerythrityl Tetraisostearate, Isononyl \r\nIsononanoate, Dimethicone Crosspolymer, Phenoxyethanol, Phenyl \r\nTrimethicone, Magnesium Stearate, PEG-8 Dimethicone, Paraffin, \r\nIsopropyl, Titanium Triisostearate, Octyldodecanol, VP/Hexadecene \r\nCopolymer, PTFE, Glycolipids, Bismuth Oxychloride, Tin Oxide, Aluminum \r\nHydroxide, Magnesium Myristate&lt;br&gt;May conn : &lt;br&gt;CI 77891 , CI 77491, CI 77499, CI 77510, CI 77007, CI 15850, CI 77266, CI 45410, CI 77742, CI 77492, CI 16035, CI 42090&lt;p&gt;&lt;/p&gt;', 1, 0, '2024-06-04 08:28:56');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(30) NOT NULL,
  `order_id` int(30) NOT NULL,
  `total_amount` double NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `order_id`, `total_amount`, `date_created`) VALUES
(6, 6, 22500, '2024-06-02 10:17:01'),
(7, 7, 22500, '2024-06-02 22:30:19'),
(8, 8, 50000, '2024-06-04 08:15:43'),
(9, 9, 50000, '2024-06-07 14:11:20'),
(10, 10, 200000, '2024-06-07 14:12:18');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'Toko BEE PRETTY'),
(6, 'short_name', 'Bee Pretty'),
(11, 'logo', 'uploads/logo2.png?v=1645065716'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/cover-1645065725.jpg?v=1645065725');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'min', 'bee', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/avatars/1.png?v=1645064505', NULL, 1, '2021-01-20 14:02:37', '2024-06-02 23:37:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_id` (`inventory_id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `order_list`
--
ALTER TABLE `order_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_id` (`inventory_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `brand_id` (`brand_id`,`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `order_list`
--
ALTER TABLE `order_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_list`
--
ALTER TABLE `order_list`
  ADD CONSTRAINT `order_list_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_list_ibfk_2` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
